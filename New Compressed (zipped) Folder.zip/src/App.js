import React,{useState} from 'react';
import './App.css';
import ContactManager from './components/contactManager';
import DisplayInfo from "./components/displayInfo"

const App = () =>{
  const usersData = [] 
  const [users, setUsers] = useState(usersData)

  const addUser = user => {
    user.id = users.length + 1
    setUsers([...users, user])
  }
  return(
    <div className="container">
  <header className="App-header">
    <h2>Contact Manager <hr></hr></h2>
    
    <div className="flex-large">
    <ContactManager addUser={addUser}  />
    <hr></hr>
    </div>
   
    <div className="flex-large">
    <DisplayInfo users={users}/>
    </div>
  </header>
</div>
  )
  
} 

export default App;
