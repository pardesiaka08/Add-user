import React from "react";
import { useForm } from "react-hook-form";


const BasicInputField = ({type,name,placeholder,value,onChange,className,pattern}) => {
    const { register} = useForm();
    console.log(pattern)
    return(
        <input type={type} name={name} placeholder={placeholder} value={value} onChange={onChange} className={className} ref={register({ required: true, pattern:/^[a-zA-Z ]{3,30}$/})}  />
    )
}



export default BasicInputField;