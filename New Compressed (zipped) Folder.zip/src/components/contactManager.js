import React,{useState} from 'react';
import { useForm } from "react-hook-form";
import BasicInputField from "./basicInputField.js";
import "./contactManager.css"

const ContactManager = (props) => {
    const { register, handleSubmit } = useForm();
    const initialFormState = { id: null, name:'',phone:'',email:''}
    const [user, setUser] = useState(initialFormState)

    const handleInputChange = event => {
    const { name, value } = event.target

    setUser({ ...user, [name]: value })
    console.log([name],"haaaaaaaaaaaa")
  }
    const onSubmit = (event) =>{
        // event.preventDefault()
        props.addUser(user)
        setUser(initialFormState)
    }
    
    return (
        <form onSubmit={handleSubmit(onSubmit)} >
          <div className="row">
            <div className="col-sm-3 form-group">
            <input type="text" name="name" placeholder="Name" className="form-control .has-error .form-control:focus" value={user.name} onChange={handleInputChange} ref={register({ required: true, pattern:/^[a-zA-Z ]{3,30}$/})} />
          </div>
          <div className="col-sm-3 md-2 form-group">
          <input type="tel" name="phone" placeholder="Phone(digit only)" className="form-control .has-error .form-control:focus"  value={user.phone} onChange={handleInputChange} ref={register({ required: true, pattern:/^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/})}/>
          </div>
          <div className="col-sm-3 md-2 form-group">
          <input type="email" name="email" placeholder="Email" className="form-control .has-error .form-control:focus"  value={user.email} onChange={handleInputChange} ref={register({ required: true, pattern:/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3,4}$/})}/>
         </div>
         <div className=" col-sm-3 md-2 form-group">
        <button type="submit" className="btn btn-primary">Add Contact</button>
         </div>
        </div>
      </form>
    )
}
export default ContactManager