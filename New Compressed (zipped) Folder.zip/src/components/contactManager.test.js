import React from 'react'

describe('<ContactManager>', () => {
    it('renders correctly', () => {
        expect(true).toEqual(false)
    })
})