import React from 'react'

const DisplayInfo = props => (
  <table className="table table-striped">
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">Phone</th>
        <th scope="col">Email</th>
      </tr>
    </thead>
    <tbody>
      {props.users.length > 0 ? (
        props.users.map(user => (
          <tr key={user.id}>
            <td>{user.name}</td>
            <td>{user.phone}</td>
            <td>{user.email}</td>
           
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan={3}></td>
        </tr>
      )}
    </tbody>
  </table>
)
export default DisplayInfo;